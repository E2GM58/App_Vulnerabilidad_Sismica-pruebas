class DatabaseResponse<T> {
  final bool success;
  final T? data;
  final String? error;
  final int? statusCode;

  DatabaseResponse._({
    required this.success,
    this.data,
    this.error,
    this.statusCode,
  });

  factory DatabaseResponse.success(T data) {
    return DatabaseResponse._(success: true, data: data);
  }

  factory DatabaseResponse.error(String error, [int? statusCode]) {
    return DatabaseResponse._(success: false, error: error, statusCode: statusCode);
  }
}